"""Color goups used by cloth color randomization"""  

import bpy #type: ignore

color_dict = {
    'C0': (
        '88C1FF',
        '5C97FF',
        'F5FFFF',
        '777C7F',
        '2F3133',
        '46787B',
        '9EC4BD',
        '7B366F',
        '5B7728',
        '1F3257'
    ),  # Denim
}

